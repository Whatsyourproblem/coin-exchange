module.exports = {
  NODE_ENV: '"production"',
  ENV_CONFIG: '"prod"',
  BASE_API: '"http://114.119.32.11:9000"',
  PROTOCOL:'"https://"',
}
