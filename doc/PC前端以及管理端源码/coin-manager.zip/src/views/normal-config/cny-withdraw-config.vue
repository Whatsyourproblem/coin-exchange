<template>
  <div>
    场外交易提现配置
  </div>
</template>

<script>

  export default {
    data() {
      return {
      }
    },
    methods: {
    }
  }
</script>

<style scoped>

</style>

