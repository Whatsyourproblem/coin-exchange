<template>
  <div>
    合作渠道管理
  </div>
</template>

<script>

  export default {
    data() {
      return {
      }
    },
    methods: {
    }
  }
</script>

<style scoped>

</style>

