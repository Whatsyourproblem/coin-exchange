import * as types from './mutation-types'
import {loginRegist} from "../api/loginRegist";
import {OK} from "../api/config";
import { mapMutations } from 'vuex'

// export const isLogin = function ({commit, state}, isLogin) {
//   commit(types.SET_ISLOGIN, isLogin)
// }
