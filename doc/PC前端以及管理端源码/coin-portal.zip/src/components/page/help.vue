<template>
  <div class="ucenter-wrap help-page" v-wechat-title="$t('m.footer.help')">
  <NavHeader></NavHeader>
    <div class="ucenter-content">
      <div class="ucenter-row">
        <sidebar></sidebar>
        <div class="ucenter-main">
          <div class="ucenter-header">
              <h3 class="title">{{$t('m.footer.help')}}</h3>
          </div>
          <div class="ucenter-body">
            <p>一、注册登录</p>
            <p>（1）在浏览器网址访问栏输入http://www.pcn.li 点击右上角注册按钮进行注册。</p>
            <p><img src="../../assets/help/1.png" alt="" width="600"></p>
            （2）点击注册进入如下页面（<span class="red">建议使用手机号码进行注册</span>），
            填写完信息后点击 <span class="red">我已阅读并同意服务条款</span> ，
            <span class="red">然后点击同意条款并注册按钮</span>。
            <p><img src="../../assets/help/2.png" alt="" width="600"></p>
            <p>（3）注册完成进行登录</p>
            <p><img src="../../assets/help/3.png" alt="" width="600"></p>
            <p>二、账号实名认证及修改密码、邀请奖励</p>
            <p>（1）首次注册登录进入公链网交易平台后，进行
              <span class="red">实名认证及设置密码</span></p>
            <p><img src="../../assets/help/4.png" alt="" width="600"></p>
              <p>如果不想首次注册完成就设置，可以之后在个人中心里面进行设置（如下图）</p>
            <p><img src="../../assets/help/5.png" alt="" width="600"></p>
            <p>个人中心，<span class="red">账号设置：用户名、注册账号（手机号码）、邀请码、邀请链接及二维码，可直接复制粘贴给好友邀请，二维码可直接发给好友进行扫一扫注册。</span></p>
            <p><img src="../../assets/help/6.png" alt="" width="600"></p>
            <p>（3）身份验证：<span class="red">需提交真实信息</span></p>
            <p><img src="../../assets/help/7.png" alt="" width="600"></p>
            <p>（4）高级认证：<span class="red">需提交真实信息，认证结果需要等待一到两个工作日</span></p>
            <p><img src="../../assets/help/8.png" alt="" width="600"></p>
            <p><img src="../../assets/help/9.png" alt="" width="600"></p>
            <p>（5）修改手机号码</p>
            <p><img src="../../assets/help/10.png" alt="" width="600"></p>
            <p>（6）修改登录密码</p>
            <p><img src="../../assets/help/11.png" alt="" width="600"></p>
            <p>（7）设置修改交易密码，如果<span class="red">忘记原交易密码，可点击忘记密码进行重置</span></p>
            <p><img src="../../assets/help/12.png" alt="" width="600"></p>
            <p>（8）谷歌验证：需下载谷歌验证器，具体操作流程 <span class="red">（https://www.kafan.cn/edu/4262426.html）</span></p>
            <p><img src="../../assets/help/13.png" alt="" width="600"></p>
            <p>（9）邀请奖励</p>
            <p><img src="../../assets/help/14.png" alt="" width="600"></p>
            <p>三、交易区域</p>
            <p>1、币币交易</p>
            <p>（1）进入http://www.pcn.li 公链网主页后，点击左上方的 <span class="red">币币交易或者点击交易区域的币种进入交易盘面及添加自选币种</span></p>
            <p><img src="../../assets/help/15.png" alt="" width="600"></p>
            <p>K线交易、选择币种、买卖委托单及相关操作、全站成交记录等操作</p>
            <p><img src="../../assets/help/16.png" alt="" width="600"></p>
            <p>2、场外交易</p>
            <p>（1）需先添加银行卡</p>
            <p><img src="../../assets/help/17.png" alt="" width="600"></p>

            <p>（2）进行买卖操作</p>
            <p><img src="../../assets/help/18.png" alt="" width="600"></p>

            <p>四、资产管理</p>
            <p>1、首页点击右上角资产管理下拉菜单选择，进入账户资产列表，进行充提币操作及所持币种详情</p>
            <p><img src="../../assets/help/19.png" alt="" width="600"></p>


            <p>3、委托记录，选择交易对，可查看该币种委托记录</p>
            <p><img src="../../assets/help/20.png" alt="" width="600"></p>


            <p>4、成交记录，选择交易对，可查看该币种成交记录</p>
            <p><img src="../../assets/help/21.png" alt="" width="600"></p>
            <p>5、选择币种，查看充币记录</p>
            <p><img src="../../assets/help/22.png" alt="" width="600"></p>
            <p>选择币种，查看提币记录</p>
            <p><img src="../../assets/help/23.png" alt="" width="600"></p>
            <p>7、添加提币地址</p>
            <p><img src="../../assets/help/24.png" alt="" width="600"></p>
            <p>五、公告及客服、上币申请区域 <span class="red">（在首页或者场外交易、资产管理等菜单下，拉到最底部点击按钮）</span></p>
            <p><img src="../../assets/help/25.png" alt="" width="600"></p>

            <p>1、本站公告（<span class="red">公链网所有公告及通知等官方信息展示</span>）</p>
            <p><img src="../../assets/help/26.png" alt="" width="600"></p>

            <p>2、公链网交易费率</p>
            <p><img src="../../assets/help/27.png" alt="" width="600"></p>
            <p>3、公链网服务协议及投资风险须知</p>
            <p><img src="../../assets/help/28.png" alt="" width="600"></p>
            <p>4、客服工单，任何问题也可以在这里发布，客服会尽快进行回复</p>
            <p><img src="../../assets/help/29.png" alt="" width="600"></p>

            <p>5、上币申请（<span class="red">发送申请及币种相关信息到pcn.li@hotmail.com，公链网在10个工作日内答复</span>）</p>
            <p><img src="../../assets/help/30.png" alt="" width="600"></p>
          </div>
        </div>
      </div>
    </div>
    <div class="ucenter-footer">
      <mFooter class="footer-bar"></mFooter>
    </div>
  </div>
</template>
<style lang="stylus">
  @import "~common/stylus/usercenter"
  .help-page{
    .ucenter-body{
      line-height 1.777
      h3{
        font-weight bold
        font-size 15px
        color #333
        margin-bottom 15px
      }
      p{
        font-size 14px
        color #666666
        margin-bottom 5px
        a{
          color #7392FF
        }
      }
    }
    .el-tabs__nav-wrap::after{
      background-color #fff
    }
    .el-tabs__item{
      padding 0
      margin-right 30px
      color #7392ff
      height 20px
      line-height 20px
      border-bottom 1px solid #7392ff
    }
    .el-tabs__item.is-active{
      color #999
      border-bottom none
    }
    .el-tabs__active-bar{
      background-color #fff
    }
    strong{
      font-weight bold
    }
    .red{
      color #f00
    }
  }
</style>
<script>
  import NavHeader from 'components/nav-header/nav-header'
  import sidebar from 'components/page/sidebar'
  import mFooter from 'components/m-footer/m-footer'

  export default {
    data () {
      return {
        activeName: '1'
      }
    },
    components : {NavHeader,sidebar,mFooter}
  }
</script>
