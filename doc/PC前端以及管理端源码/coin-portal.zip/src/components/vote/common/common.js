export default {
    // apihost:"http://192.168.2.143:8080/" //设置开发阶段或是生产阶段请求的IP地址和端口
}
