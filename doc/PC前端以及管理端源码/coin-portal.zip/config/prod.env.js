//测试环境
module.exports = {
  NODE_ENV: '"production"',
  BASE_API:'"http://47.75.125.96"',
  DOMAIN: '"http://47.75.125.96"',
  SOCKET_URL:'"ws://47.75.47.120:8326"'
}
