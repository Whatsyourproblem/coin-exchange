//压力测试环境
module.exports = {
  NODE_ENV: '"site"',
   BASE_API: '"http://www.pcn.li"',
   DOMAIN: '"http://pcn.li"',
   SOCKET_URL:'"ws://ws.pcn.li/"'
}
