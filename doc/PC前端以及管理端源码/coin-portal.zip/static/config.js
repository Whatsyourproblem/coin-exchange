window.config={
  // 测试环境服务器地址
	socketServer:'ws://127.0.0.1:8326/',
	ajaxServer: 'http://127.0.0.1',
  // 生产环境服务器地址
	//socketServer:'ws://103.71.178.73:8326/',
	//ajaxServer: 'http://103.71.178.73/v2/s'
}

